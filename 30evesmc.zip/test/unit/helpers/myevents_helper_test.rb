require 'test_helper'

class MyeventsHelperTest < ActionView::TestCase
end
