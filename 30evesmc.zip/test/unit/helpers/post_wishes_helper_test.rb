require 'test_helper'

class PostWishesHelperTest < ActionView::TestCase
end
