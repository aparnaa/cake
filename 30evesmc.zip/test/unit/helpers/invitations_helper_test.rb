require 'test_helper'

class InvitationsHelperTest < ActionView::TestCase
end
