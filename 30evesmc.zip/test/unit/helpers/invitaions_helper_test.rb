require 'test_helper'

class InvitaionsHelperTest < ActionView::TestCase
end
