require 'test_helper'

class OrganisationsHelperTest < ActionView::TestCase
end
