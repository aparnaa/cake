require 'test_helper'

class InvoicesHelperTest < ActionView::TestCase
end
