class Organisation < ActiveRecord::Base


end
