class Invoice < ActiveRecord::Base
end
