class Transaction < ActiveRecord::Base

belongs_to :member 

end
