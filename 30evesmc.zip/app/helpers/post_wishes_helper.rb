module PostWishesHelper
end
