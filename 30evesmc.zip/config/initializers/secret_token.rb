# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Newapp::Application.config.secret_token = 'a75077448588401dd10bbf7bd8140563d4dac71e5c0acd47682068d3f18e4cb506bc029620164f5723fda4aaec502400143ef6a446787622e40880c699e12fde'
